﻿using System;

namespace ExtBRP
{
    public class ClientA : BRP.Classes.BaseRule
    {
        /// <summary>
        ///     Some other Methods
        /// </summary>
        private void FOO()
        {
            Console.WriteLine("Client A: Hello World");
        }

        /// <summary>
        ///     Separate Client implementation in Secondary External Package should inherit our Base Class
        /// </summary>
        /// <returns>True or False on context</returns>
        public override bool Execute()
        {
            if (base.Execute())
            {
                FOO();
                Console.WriteLine("Client A: Executed Client Rule");
                return true;
            }
            return false;
        }
    }
}