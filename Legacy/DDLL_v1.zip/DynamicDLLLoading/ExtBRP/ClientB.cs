﻿using System;
using System.Runtime.Serialization.Formatters;
using BRP.Classes;

namespace ExtBRP
{
    public class ClientB : BRP.Classes.BaseRule
    {
        /// <summary>
        /// Some Other Method
        /// </summary>
        public void FOO()
        {
            Console.WriteLine("Hello World");
        }
    }
}