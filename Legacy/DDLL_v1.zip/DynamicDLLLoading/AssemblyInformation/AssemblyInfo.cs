﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssemblyInformation
{
    public static class AssemblyInfo
    {
        public static void DisplayAttributes(int indent, MemberInfo mi)
        {
            // Get the set of custom attributes; if none exist, just return.
            var attrs = mi.GetCustomAttributes(false);
            if (attrs.Length == 0) { return; }

            // Display the custom attributes applied to this member.
            Display(indent + 1, "Attributes:");
            foreach (var o in attrs)
            {
                Display(indent + 2, "{0}", o.ToString());
            }
        }

        // Display a formatted string indented by the specified amount.
        private static void Display(int indent, string format, params object[] param)

        {
            Console.WriteLine(new string(' ', indent * 2));
            Console.WriteLine(format, param);
        }
    }
}
