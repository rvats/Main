﻿namespace BRP.Interfaces
{
    public interface IBusinessRuleProcess
    {
        /// <summary>
        /// Our Contract Interface in External Package
        /// </summary>
        /// <returns>True or False on context</returns>
        bool Execute();
    }
}