﻿using System;
using BRP.Interfaces;

namespace BRP.Classes
{
    /// <summary>
    /// Base Class in External Package: Need to figure out a way to have this run always
    /// </summary>
    /// <returns>True or False on context</returns>
    public class BaseRule : IBusinessRuleProcess
    {
        public virtual bool Execute()
        {
            //If your application has certain rules
            var baseRule = "In an External Package - Our Application Base Rule";
            Console.WriteLine("This Rule Will Always Be Executed: " + baseRule);
            return true;
        }
    }
}