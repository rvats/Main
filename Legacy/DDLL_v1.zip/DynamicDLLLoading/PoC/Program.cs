﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using BRP.Classes;

namespace PoC
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            var assembly = typeof(Program).Assembly;
            var choice = "Y";
            do
            {
                Console.WriteLine("The Assembly MetaData Information that you are currently executing");
                Console.WriteLine(assembly);

                Console.Write("Please Type The Name of Assembly to be executed: ");
                var runTimeConsentRule = Console.ReadLine();

                var brp = (BaseRule) assembly.CreateInstance(runTimeConsentRule);

                if (brp != null)
                {
                    Console.WriteLine("Running Method from The Executing Assembly");
                    Console.WriteLine(brp.Execute());
                }
                else
                {
                    Console.WriteLine("Running Method from External Assembly");
                    var path = Directory.GetParent(Directory.GetCurrentDirectory()).FullName; //This should be configurable
                    if (path.Contains("bin"))
                    {
                        path = path.Remove(path.IndexOf("bin", StringComparison.CurrentCultureIgnoreCase));
                    }
                    path = path + "\\BusinessRuleExtension\\";
                    try
                    {
                        var extDLL = Assembly.LoadFile(path + runTimeConsentRule);
                            // You Need the Name of the dll to be loaded
                        Console.WriteLine(extDLL);

                        Console.Write("Enter the Fully resolved Class Type To Be Loaded: ");
                        var typeName = Console.ReadLine(); // You need the fully resolved name of the class type to create the instance

                        var type = extDLL.GetExportedTypes().FirstOrDefault(x => x.FullName == typeName);
                        if (type != null)
                        {
                            var c = (BaseRule) Activator.CreateInstance(type);
                            Console.WriteLine(c != null && c.Execute());
                        }
                        else
                        {
                            Console.WriteLine("Could Not Find the Required Library Class Type");
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                        Console.WriteLine("Make Sure That DLL is loaded at " + path);
                        //return;
                    }
                }

                Console.Write("Do you want to continue(Y/N): ");
                choice = Console.ReadLine();
            } while (choice != null && choice.ToUpper().Equals("Y"));
        }
    }
}