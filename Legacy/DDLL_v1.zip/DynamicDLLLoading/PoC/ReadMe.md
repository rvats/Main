The BusinessRuleProcess will just define the BaseRule and Interface
A New Project will have to be created for Implementing The Further Details whether Internal or for External Clients.