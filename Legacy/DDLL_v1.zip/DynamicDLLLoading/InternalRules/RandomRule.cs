﻿using System;
using BRP.Classes;

namespace InternalRules
{
    public class RandomRule : BaseRule
    {
        public override bool Execute()
        {
            base.Execute();
            const string Rule1 = "Random Misplaced Rule from Our Internal Rules Library";
            Console.WriteLine("External Package - " + Rule1);
            return true;
        }
    }
}