﻿using System;
using BRP.Classes;

namespace InternalRules.Classes
{
    public class RuleN : BaseRule
    {
        /// <summary>
        /// RC implementation in External Package should inherit our Base Class
        /// </summary>
        /// <returns>True or False on context</returns>
        public override bool Execute()
        {
            var Rule1 = "Rule 1 "; // This can be fetched from DB
            var RuleN = "Rule N "; // This can be static rule in the class
            Console.WriteLine("Rule N Class will have " + Rule1 + "..." + RuleN + "applied.");
            return true;
        }
    }
}