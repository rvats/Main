﻿using System;
using System.Collections.Generic;
using BRP.Classes;
using SharedLibraries;

namespace InternalRules.Classes
{
    public class Rule1 : BaseRule
    {
        /// <summary>
        /// Rule1 implementation in External Package should inherit our Base Class
        /// </summary>
        /// <returns>True or False on context</returns>
        public override bool Execute()
        {
            if (CheckConditions())
            {
                base.Execute();
                const string Rule1 = "Rule 1 from Our Internal Library";
                Console.WriteLine("External Package - " + Rule1);
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CheckConditions()
        {
            Conditions c = new Conditions();
            List<string> cv = new List<string>
            {
                "Condition1"
            };
            c.SetConditions(cv);
            if (c.GetConditions().Contains("Condition1"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}