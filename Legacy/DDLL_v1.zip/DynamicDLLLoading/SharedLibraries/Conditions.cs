﻿using System.Collections.Generic;

namespace SharedLibraries
{
    /// <summary>
    /// These Conditions will be checked for Before we execute the rule. Think of some real life cases
    /// </summary>
    public class Conditions
    {
        /// <summary>
        /// Define a condition
        /// </summary>
        private List<string> _conditions;

        public void SetConditions(List<string> conditions)
        {
            _conditions = conditions;
        }

        public List<string> GetConditions()
        {
            return _conditions;
        }

    }
}
